<?php

namespace StomtFeedback\Components;

class StomtFeedback
{
    public function getSlogan()
    {
        $slogans = '';
          

        return ($slogans);
    }
}
