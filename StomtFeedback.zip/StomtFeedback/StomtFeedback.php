<?php

namespace StomtFeedback;

use Shopware\Components\Plugin;

class StomtFeedback extends Plugin
{

}
